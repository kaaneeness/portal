"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Search, Database } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function SapContractForm() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!searchTerm) {
      toast({
        title: "Arama terimi gerekli",
        description: "Lütfen bir sözleşme numarası veya anahtar kelime girin.",
        variant: "destructive",
      })
      return
    }

    setIsSearching(true)

    try {
      // SAP arama simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Sonuç bulunamadı mesajı
      toast({
        title: "Sonuç bulunamadı",
        description: "Arama kriterlerinize uygun sözleşme bulunamadı.",
        variant: "destructive",
      })
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "SAP bağlantısı sırasında bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  return (
    <div className="space-y-6">
      <Alert>
        <Database className="h-4 w-4" />
        <AlertTitle>SAP Entegrasyonu</AlertTitle>
        <AlertDescription>
          SAP entegrasyonu henüz tamamlanmadı. Bu özellik yakında kullanıma sunulacaktır.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSearch} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="searchTerm">Sözleşme Numarası veya Anahtar Kelime</Label>
          <div className="flex space-x-2">
            <Input
              id="searchTerm"
              placeholder="Sözleşme numarası veya anahtar kelime girin"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              disabled={isSearching}
            />
            <Button type="submit" disabled={isSearching || !searchTerm}>
              {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              <span className="ml-2">Ara</span>
            </Button>
          </div>
        </div>
      </form>

      <div className="rounded-md border p-8 flex flex-col items-center justify-center text-center">
        <Database className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium">SAP'den Veri Bulunamadı</h3>
        <p className="text-sm text-muted-foreground mt-2 mb-4">
          Arama yaparak SAP'deki sözleşmeleri görüntüleyebilirsiniz.
        </p>
      </div>
    </div>
  )
}
