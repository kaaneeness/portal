"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { FlowApprovalSchema } from "@/components/flow-approval-schema"
import { FlowDocumentUpload } from "@/components/flow-document-upload"
import { FlowDocuments } from "@/components/flow-documents"
import { FlowComments } from "@/components/flow-comments"
import { FlowHistory } from "@/components/flow-history"
import { Users, MessageSquare, History, FileText, Plus } from "lucide-react"
import { db } from "@/lib/db"
import type { ContractFlow } from "@/types"

interface FlowManagementProps {
  flow: ContractFlow
  isResponsible: boolean
}

export function FlowManagement({ flow, isResponsible }: FlowManagementProps) {
  const [activeTab, setActiveTab] = useState("approvals")
  const [isAddApproverDialogOpen, setIsAddApproverDialogOpen] = useState(false)
  const [approverType, setApproverType] = useState<"department" | "committee" | "">("")
  const [approverId, setApproverId] = useState("")
  const [notes, setNotes] = useState("")
  const { toast } = useToast()

  const handleAddApprover = () => {
    if (!approverType || !approverId) {
      toast({
        title: "Eksik bilgiler",
        description: "Lütfen onaylayıcı türünü ve onaylayıcıyı seçin.",
        variant: "destructive",
      })
      return
    }

    // Onaylayıcı ekleme simülasyonu
    toast({
      title: "Onaylayıcı eklendi",
      description: "Onaylayıcı başarıyla eklendi.",
    })

    // Diyaloğu kapat ve formu temizle
    setIsAddApproverDialogOpen(false)
    setApproverType("")
    setApproverId("")
    setNotes("")
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="approvals" className="flex items-center">
            <Users className="mr-2 h-4 w-4" />
            Onay Akışı
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center">
            <FileText className="mr-2 h-4 w-4" />
            Belgeler
          </TabsTrigger>
          <TabsTrigger value="comments" className="flex items-center">
            <MessageSquare className="mr-2 h-4 w-4" />
            Yorumlar
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center">
            <History className="mr-2 h-4 w-4" />
            Geçmiş
          </TabsTrigger>
        </TabsList>

        <TabsContent value="approvals" className="space-y-4">
          {isResponsible && (
            <div className="flex justify-end">
              <Dialog open={isAddApproverDialogOpen} onOpenChange={setIsAddApproverDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Onaylayıcı Ekle
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Onaylayıcı Ekle</DialogTitle>
                    <DialogDescription>Sözleşme akışına yeni bir onaylayıcı ekleyin.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <label htmlFor="approver-type">Onaylayıcı Türü</label>
                      <Select
                        value={approverType}
                        onValueChange={(value) => setApproverType(value as "department" | "committee")}
                      >
                        <SelectTrigger id="approver-type">
                          <SelectValue placeholder="Onaylayıcı türü seçin" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="department">Departman</SelectItem>
                          <SelectItem value="committee">Komite</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {approverType === "department" && (
                      <div className="space-y-2">
                        <label htmlFor="department">Departman</label>
                        <Select value={approverId} onValueChange={setApproverId}>
                          <SelectTrigger id="department">
                            <SelectValue placeholder="Departman seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            {db.departments.map((department) => (
                              <SelectItem key={department.id} value={department.id}>
                                {department.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {approverType === "committee" && (
                      <div className="space-y-2">
                        <label htmlFor="committee">Komite</label>
                        <Select value={approverId} onValueChange={setApproverId}>
                          <SelectTrigger id="committee">
                            <SelectValue placeholder="Komite seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            {db.committees.map((committee) => (
                              <SelectItem key={committee.id} value={committee.id}>
                                {committee.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <div className="space-y-2">
                      <label htmlFor="notes">Notlar (İsteğe Bağlı)</label>
                      <Textarea
                        id="notes"
                        placeholder="Onaylayıcı için notlar..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddApproverDialogOpen(false)}>
                      İptal
                    </Button>
                    <Button onClick={handleAddApprover}>
                      <Plus className="mr-2 h-4 w-4" />
                      Ekle
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          )}

          <FlowApprovalSchema approvers={flow.approvers} canManage={isResponsible} flowId={flow.id} />
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          {isResponsible && <FlowDocumentUpload flowId={flow.id} />}

          <Card>
            <CardHeader>
              <CardTitle>Belgeler</CardTitle>
            </CardHeader>
            <CardContent>
              <FlowDocuments documents={flow.documents} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comments">
          <Card>
            <CardHeader>
              <CardTitle>Yorumlar</CardTitle>
            </CardHeader>
            <CardContent>
              <FlowComments comments={flow.comments} flowId={flow.id} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Geçmiş</CardTitle>
            </CardHeader>
            <CardContent>
              <FlowHistory history={flow.history} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
