"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

export function SecuritySettings() {
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newPassword !== confirmPassword) {
      toast({
        title: "Şifreler eşleşmiyor",
        description: "Yeni şifre ve şifre onayı aynı olmalıdır.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Şifre değiştirme simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Şifre değiştirildi",
        description: "Şifreniz başarıyla güncellendi.",
      })

      // Formu temizle
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Şifre değiştirilirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleTwoFactorChange = async (checked: boolean) => {
    setTwoFactorEnabled(checked)

    toast({
      title: checked ? "İki faktörlü doğrulama etkinleştirildi" : "İki faktörlü doğrulama devre dışı bırakıldı",
      description: checked ? "Hesabınız artık daha güvenli." : "İki faktörlü doğrulama devre dışı bırakıldı.",
    })
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <h3 className="text-lg font-medium">Şifre Değiştir</h3>

        <div className="grid gap-2">
          <Label htmlFor="current-password">Mevcut Şifre</Label>
          <Input
            id="current-password"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            required
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="new-password">Yeni Şifre</Label>
          <Input
            id="new-password"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="confirm-password">Şifre Onayı</Label>
          <Input
            id="confirm-password"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>

        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Değiştiriliyor...
            </>
          ) : (
            "Şifreyi Değiştir"
          )}
        </Button>
      </form>

      <Separator />

      <div className="space-y-4">
        <h3 className="text-lg font-medium">İki Faktörlü Doğrulama</h3>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="two-factor">İki faktörlü doğrulama</Label>
            <p className="text-sm text-muted-foreground">Hesabınıza giriş yaparken ek bir güvenlik katmanı ekleyin.</p>
          </div>
          <Switch id="two-factor" checked={twoFactorEnabled} onCheckedChange={handleTwoFactorChange} />
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <h3 className="text-lg font-medium">Oturum Yönetimi</h3>

        <Button variant="outline" className="w-full">
          Tüm Diğer Cihazlardan Çıkış Yap
        </Button>
      </div>
    </div>
  )
}
