"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Search, Database } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export function SapFlowForm() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [selectedPo, setSelectedPo] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const router = useRouter()
  const { toast } = useToast()

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!searchTerm) {
      toast({
        title: "Arama terimi gerekli",
        description: "Lütfen bir PO numarası veya firma adı girin.",
        variant: "destructive",
      })
      return
    }

    setIsSearching(true)

    try {
      // SAP arama simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Örnek sonuçlar
      const mockResults = [
        {
          id: "1",
          poNumber: "PO-2023-0123",
          counterpartyName: "ABC Teknoloji A.Ş.",
          amount: "120.000,00 TL",
          date: "15.06.2023",
        },
        {
          id: "2",
          poNumber: "PO-2023-0124",
          counterpartyName: "ABC Teknoloji A.Ş.",
          amount: "45.000,00 TL",
          date: "20.06.2023",
        },
      ]

      setSearchResults(mockResults)
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "SAP bağlantısı sırasında bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedPo) {
      toast({
        title: "Seçim yapılmadı",
        description: "Lütfen bir PO seçin.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Akış başlatma simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Başarılı mesajı göster
      toast({
        title: "Akış başlatıldı",
        description: "Sözleşme akışı başarıyla başlatıldı.",
      })

      // Akışlar sayfasına yönlendir
      router.push("/dashboard/flows")
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Akış başlatılırken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <Alert>
        <Database className="h-4 w-4" />
        <AlertTitle>SAP Entegrasyonu</AlertTitle>
        <AlertDescription>
          SAP entegrasyonu henüz tamamlanmadı. Bu özellik yakında kullanıma sunulacaktır. Şu anda örnek veriler
          gösterilmektedir.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSearch} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="searchTerm">PO Numarası veya Firma Adı</Label>
          <div className="flex space-x-2">
            <Input
              id="searchTerm"
              placeholder="PO numarası veya firma adı girin"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              disabled={isSearching}
            />
            <Button type="submit" disabled={isSearching || !searchTerm}>
              {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              <span className="ml-2">Ara</span>
            </Button>
          </div>
        </div>
      </form>

      {searchResults.length > 0 ? (
        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="rounded-md border">
              <RadioGroup value={selectedPo || ""} onValueChange={setSelectedPo}>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]"></TableHead>
                      <TableHead>PO Numarası</TableHead>
                      <TableHead>Firma Adı</TableHead>
                      <TableHead>Tutar</TableHead>
                      <TableHead>Tarih</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {searchResults.map((result) => (
                      <TableRow key={result.id}>
                        <TableCell>
                          <RadioGroupItem value={result.id} id={`po-${result.id}`} />
                        </TableCell>
                        <TableCell>{result.poNumber}</TableCell>
                        <TableCell>{result.counterpartyName}</TableCell>
                        <TableCell>{result.amount}</TableCell>
                        <TableCell>{result.date}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </RadioGroup>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" type="button" onClick={() => router.push("/dashboard/flows")}>
                İptal
              </Button>
              <Button type="submit" disabled={isSubmitting || !selectedPo}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Başlatılıyor...
                  </>
                ) : (
                  "Akışı Başlat"
                )}
              </Button>
            </div>
          </div>
        </form>
      ) : (
        <div className="rounded-md border p-8 flex flex-col items-center justify-center text-center">
          <Database className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">SAP'den Veri Bulunamadı</h3>
          <p className="text-sm text-muted-foreground mt-2 mb-4">
            Arama yaparak SAP'deki satınalma siparişlerini (PO) görüntüleyebilirsiniz.
          </p>
        </div>
      )}
    </div>
  )
}
