"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { db } from "@/lib/db"
import { Loader2 } from "lucide-react"

export function ManualFlowForm() {
  const [title, setTitle] = useState("")
  const [counterpartyName, setCounterpartyName] = useState("")
  const [counterpartyTaxId, setCounterpartyTaxId] = useState("")
  const [poNumber, setPoNumber] = useState("")
  const [description, setDescription] = useState("")
  const [departmentId, setDepartmentId] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !counterpartyName || !departmentId) {
      toast({
        title: "Eksik bilgiler",
        description: "Lütfen gerekli alanları doldurun.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Akış başlatma simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Başarılı mesajı göster
      toast({
        title: "Akış başlatıldı",
        description: "Sözleşme akışı başarıyla başlatıldı.",
      })

      // Akışlar sayfasına yönlendir
      router.push("/dashboard/flows")
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Akış başlatılırken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid gap-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="title">
              Sözleşme Başlığı <span className="text-red-500">*</span>
            </Label>
            <Input
              id="title"
              placeholder="Sözleşme başlığını girin"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="poNumber">Satınalma (PO) Numarası</Label>
            <Input
              id="poNumber"
              placeholder="Varsa PO numarasını girin"
              value={poNumber}
              onChange={(e) => setPoNumber(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="counterpartyName">
              Karşı Taraf Adı <span className="text-red-500">*</span>
            </Label>
            <Input
              id="counterpartyName"
              placeholder="Firma veya kişi adını girin"
              value={counterpartyName}
              onChange={(e) => setCounterpartyName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="counterpartyTaxId">Vergi/TC Kimlik No</Label>
            <Input
              id="counterpartyTaxId"
              placeholder="Vergi veya TC kimlik numarasını girin"
              value={counterpartyTaxId}
              onChange={(e) => setCounterpartyTaxId(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="department">
            Departman <span className="text-red-500">*</span>
          </Label>
          <Select value={departmentId} onValueChange={setDepartmentId} required>
            <SelectTrigger id="department">
              <SelectValue placeholder="Departman seçin" />
            </SelectTrigger>
            <SelectContent>
              {db.departments.map((department) => (
                <SelectItem key={department.id} value={department.id}>
                  {department.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Açıklama</Label>
          <Textarea
            id="description"
            placeholder="Sözleşme akışı hakkında kısa bir açıklama yazın"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
          />
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button variant="outline" type="button" onClick={() => router.push("/dashboard/flows")}>
          İptal
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Başlatılıyor...
            </>
          ) : (
            "Akışı Başlat"
          )}
        </Button>
      </div>
    </form>
  )
}
