import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { db } from "@/lib/db"

export function RecentActivityList() {
  // Örnek aktivite verileri
  const activities = [
    {
      id: "1",
      user: db.users[0],
      action: "created",
      target: "contract",
      targetId: "3",
      targetName: "İş Ortaklığı Anlaşması",
      date: new Date("2023-05-10T14:30:00"),
    },
    {
      id: "2",
      user: db.users[2],
      action: "approved",
      target: "contract",
      targetId: "2",
      targetName: "Hizmet Alım Sözleşmesi",
      date: new Date("2023-04-18T10:15:00"),
    },
    {
      id: "3",
      user: db.users[1],
      action: "commented",
      target: "contract",
      targetId: "1",
      targetName: "Tedarikçi Sözleşmesi",
      date: new Date("2023-05-03T09:45:00"),
    },
    {
      id: "4",
      user: db.users[3],
      action: "submitted",
      target: "contract",
      targetId: "1",
      targetName: "Tedarikçi Sözleşmesi",
      date: new Date("2023-05-02T16:20:00"),
    },
    {
      id: "5",
      user: db.users[0],
      action: "updated",
      target: "department",
      targetId: "5",
      targetName: "Bilgi Teknolojileri",
      date: new Date("2023-04-25T11:30:00"),
    },
  ]

  // Aktiviteleri tarihe göre sırala (en yeniden en eskiye)
  const sortedActivities = [...activities].sort((a, b) => b.date.getTime() - a.date.getTime())

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  // Kullanıcı baş harflerini al
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  // Eylem açıklaması
  const getActionDescription = (activity: (typeof activities)[0]) => {
    switch (activity.action) {
      case "created":
        return "oluşturdu"
      case "approved":
        return "onayladı"
      case "commented":
        return "yorum yaptı"
      case "submitted":
        return "gönderdi"
      case "updated":
        return "güncelledi"
      default:
        return activity.action
    }
  }

  // Hedef türü
  const getTargetType = (activity: (typeof activities)[0]) => {
    switch (activity.target) {
      case "contract":
        return "sözleşme"
      case "department":
        return "departman"
      default:
        return activity.target
    }
  }

  return (
    <div className="space-y-6">
      {sortedActivities.map((activity) => (
        <div key={activity.id} className="flex gap-4">
          <Avatar className="h-10 w-10">
            <AvatarFallback>{getInitials(activity.user.name)}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <p>
              <span className="font-medium">{activity.user.name}</span>{" "}
              <span className="text-muted-foreground">
                {getTargetType(activity)} {getActionDescription(activity)}:
              </span>{" "}
              <span className="font-medium">{activity.targetName}</span>
            </p>
            <p className="text-sm text-muted-foreground">{formatDate(activity.date)}</p>
          </div>
        </div>
      ))}
    </div>
  )
}
