"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { FileText, Download, Eye } from "lucide-react"
import { db } from "@/lib/db"
import type { FlowDocument } from "@/types"

interface FlowDocumentsProps {
  documents: FlowDocument[]
}

export function FlowDocuments({ documents }: FlowDocumentsProps) {
  // Kullanıcı adını bul
  const getUserName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Belge türü adını bul
  const getDocumentTypeName = (type: FlowDocument["type"]) => {
    switch (type) {
      case "contract_draft":
        return "Sözleşme Taslağı"
      case "activity_certificate":
        return "Faaliyet Belgesi"
      case "tax_certificate":
        return "Vergi Levhası"
      case "signature_circular":
        return "İmza Sirküleri"
      case "contract_control_form":
        return "Sözleşme Kontrol Formu"
      case "support_services_form":
        return "Destek Hizmetleri Sağlayıcısı Kontrol Formu"
      case "other":
        return "Diğer"
      default:
        return "Bilinmeyen"
    }
  }

  // Durum badgesi
  const getStatusBadge = (status: FlowDocument["status"]) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Taslak</Badge>
      case "reviewed":
        return (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            İncelendi
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Onaylandı
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            Reddedildi
          </Badge>
        )
      case "final":
        return (
          <Badge variant="secondary" className="bg-purple-100 text-purple-800 hover:bg-purple-100">
            Final
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  if (documents.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">Bu akış için henüz doküman yüklenmemiş.</div>
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Doküman</TableHead>
              <TableHead>Tür</TableHead>
              <TableHead>Versiyon</TableHead>
              <TableHead>Durum</TableHead>
              <TableHead>Yükleyen</TableHead>
              <TableHead>Tarih</TableHead>
              <TableHead className="text-right">İşlemler</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {documents.map((document) => (
              <TableRow key={document.id}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-blue-500" />
                    <span>{document.name}</span>
                  </div>
                </TableCell>
                <TableCell>{getDocumentTypeName(document.type)}</TableCell>
                <TableCell>v{document.version}</TableCell>
                <TableCell>{getStatusBadge(document.status)}</TableCell>
                <TableCell>{getUserName(document.uploadedBy)}</TableCell>
                <TableCell>{formatDate(document.uploadedAt)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={document.url} target="_blank">
                        <Eye className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={document.url} download>
                        <Download className="h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
