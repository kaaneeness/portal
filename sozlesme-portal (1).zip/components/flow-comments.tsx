"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Loader2, Send } from "lucide-react"
import { db } from "@/lib/db"
import { useToast } from "@/components/ui/use-toast"
import type { FlowComment } from "@/types"

interface FlowCommentsProps {
  comments: FlowComment[]
  flowId: string
}

export function FlowComments({ comments, flowId }: FlowCommentsProps) {
  const [newComment, setNewComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  // Varsayılan olarak admin kullanıcısını kullan
  const currentUser = {
    id: "1",
    name: "Admin Kullanıcı",
    email: "admin@sirket.com",
    role: "admin",
    departmentId: "1",
  }

  // Kullanıcı adını bul
  const getUserName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Kullanıcı baş harflerini al
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newComment.trim()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Yorum ekleme simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Başarılı mesajı göster
      toast({
        title: "Yorum eklendi",
        description: "Yorumunuz başarıyla eklendi.",
      })

      // Formu temizle
      setNewComment("")
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Yorum eklenirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-6">
        {comments.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">Bu akış için henüz yorum yapılmamış.</div>
        ) : (
          comments.map((comment) => {
            const userName = getUserName(comment.userId)
            return (
              <div key={comment.id} className="flex gap-4">
                <Avatar className="h-10 w-10">
                  <AvatarFallback>{getInitials(userName)}</AvatarFallback>
                </Avatar>
                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{userName}</p>
                    <p className="text-sm text-muted-foreground">{formatDate(comment.createdAt)}</p>
                  </div>
                  <p className="text-sm">{comment.text}</p>
                </div>
              </div>
            )
          })
        )}
      </div>

      <Separator />

      <form onSubmit={handleSubmitComment} className="space-y-4">
        <Textarea
          placeholder="Yorumunuzu yazın..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          rows={3}
        />
        <div className="flex justify-end">
          <Button type="submit" disabled={isSubmitting || !newComment.trim()}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Gönderiliyor...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Gönder
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  )
}
