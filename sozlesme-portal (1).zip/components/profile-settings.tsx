"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Loader2, Upload } from "lucide-react"
import { db } from "@/lib/db"

interface ProfileSettingsProps {
  user: {
    id: string
    name: string
    email: string
    role: string
    departmentId: string
  }
}

export function ProfileSettings({ user }: ProfileSettingsProps) {
  const [name, setName] = useState(user?.name || "")
  const [email, setEmail] = useState(user?.email || "")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  // Kullanıcının departmanını bul
  const department = db.departments.find((d) => d.id === user?.departmentId)

  // Kullanıcı baş harflerini al
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Profil güncelleme simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Profil güncellendi",
        description: "Profil bilgileriniz başarıyla güncellendi.",
      })
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Profil güncellenirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center gap-4">
        <Avatar className="h-20 w-20">
          <AvatarFallback className="text-lg">{getInitials(name)}</AvatarFallback>
        </Avatar>

        <div>
          <Button variant="outline" type="button" className="mb-2">
            <Upload className="mr-2 h-4 w-4" />
            Fotoğraf Yükle
          </Button>
          <p className="text-sm text-muted-foreground">JPG, GIF veya PNG. Maksimum 1MB.</p>
        </div>
      </div>

      <Separator />

      <div className="grid gap-4 md:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="name">Ad Soyad</Label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="email">E-posta</Label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="role">Rol</Label>
          <Input
            id="role"
            value={user?.role === "admin" ? "Yönetici" : user?.role === "manager" ? "Müdür" : "Kullanıcı"}
            disabled
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="department">Departman</Label>
          <Input id="department" value={department?.name || ""} disabled />
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Kaydediliyor...
            </>
          ) : (
            "Değişiklikleri Kaydet"
          )}
        </Button>
      </div>
    </form>
  )
}
