"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { BarChart, FileText, Home, ListChecks, Plus, Settings, Users, GitPullRequest } from "lucide-react"

export function Sidebar() {
  const pathname = usePathname()

  // Varsayılan olarak admin kullanıcısı
  const isAdmin = true

  const links = [
    { href: "/dashboard", label: "Dashboard", icon: Home },
    { href: "/dashboard/contracts", label: "Sözleşmeler", icon: FileText },
    { href: "/dashboard/flows", label: "Akışlar", icon: GitPullRequest },
    { href: "/dashboard/approvals", label: "Onay Bekleyenler", icon: ListChecks },
  ]

  const adminLinks = [
    { href: "/dashboard/departments", label: "Departmanlar", icon: Users },
    { href: "/dashboard/reports", label: "Raporlar", icon: BarChart },
    { href: "/dashboard/settings", label: "Ayarlar", icon: Settings },
  ]

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h1 className="text-xl font-bold">Sözleşme Takip</h1>
      </div>

      <div className="p-4">
        <Button asChild className="w-full">
          <Link href="/dashboard/flows/new">
            <Plus className="mr-2 h-4 w-4" />
            Yeni Akış Başlat
          </Link>
        </Button>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium",
              pathname === link.href
                ? "bg-gray-100 text-gray-900"
                : "text-gray-500 hover:text-gray-900 hover:bg-gray-50",
            )}
          >
            <link.icon className="h-4 w-4" />
            {link.label}
          </Link>
        ))}

        {isAdmin && (
          <>
            <div className="pt-4 pb-2">
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Yönetim</div>
            </div>

            {adminLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium",
                  pathname === link.href
                    ? "bg-gray-100 text-gray-900"
                    : "text-gray-500 hover:text-gray-900 hover:bg-gray-50",
                )}
              >
                <link.icon className="h-4 w-4" />
                {link.label}
              </Link>
            ))}
          </>
        )}
      </nav>
    </div>
  )
}
