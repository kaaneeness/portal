import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { db } from "@/lib/db"
import type { FlowHistory } from "@/types"

interface FlowHistoryProps {
  history: FlowHistory[]
}

export function FlowHistory({ history }: FlowHistoryProps) {
  // Kullanıcı adını bul
  const getUserName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Kullanıcı baş harflerini al
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  if (history.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">Bu akış için henüz geçmiş kaydı bulunmuyor.</div>
  }

  // Geçmişi tarihe göre sırala (en yeniden en eskiye)
  const sortedHistory = [...history].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())

  return (
    <div className="relative space-y-6 pl-6 before:absolute before:left-2.5 before:top-0 before:h-full before:w-px before:bg-border">
      {sortedHistory.map((item) => {
        const userName = getUserName(item.userId)
        return (
          <div key={item.id} className="relative">
            <div className="absolute -left-6 top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-background ring-2 ring-border">
              <div className="h-2 w-2 rounded-full bg-primary" />
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarFallback className="text-xs">{getInitials(userName)}</AvatarFallback>
                </Avatar>
                <p className="text-sm font-medium">{userName}</p>
                <p className="text-xs text-muted-foreground">{formatDate(item.timestamp)}</p>
              </div>
              <p className="text-sm">{item.action}</p>
              {item.details && <p className="text-xs text-muted-foreground">{item.details}</p>}
            </div>
          </div>
        )
      })}
    </div>
  )
}
