"use client"
import { CheckCircle, Clock, File, XCircle } from "lucide-react"

interface ContractStatusChartProps {
  data: {
    draft: number
    review: number
    approved: number
    rejected: number
    expired: number
  }
}

export function ContractStatusChart({ data }: ContractStatusChartProps) {
  // Bu bileşen gerçek bir grafik kütüphanesi kullanılarak geliştirilebilir
  // Örneğin: Chart.js, Recharts, veya D3.js

  const total = Object.values(data).reduce((sum, count) => sum + count, 0)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center gap-2 rounded-lg border p-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100">
            <File className="h-4 w-4 text-gray-500" />
          </div>
          <div>
            <div className="text-sm font-medium">Taslak</div>
            <div className="text-2xl font-bold">{data.draft}</div>
          </div>
        </div>

        <div className="flex items-center gap-2 rounded-lg border p-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-100">
            <Clock className="h-4 w-4 text-amber-500" />
          </div>
          <div>
            <div className="text-sm font-medium">İncelemede</div>
            <div className="text-2xl font-bold">{data.review}</div>
          </div>
        </div>

        <div className="flex items-center gap-2 rounded-lg border p-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100">
            <CheckCircle className="h-4 w-4 text-green-500" />
          </div>
          <div>
            <div className="text-sm font-medium">Onaylanmış</div>
            <div className="text-2xl font-bold">{data.approved}</div>
          </div>
        </div>

        <div className="flex items-center gap-2 rounded-lg border p-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-100">
            <XCircle className="h-4 w-4 text-red-500" />
          </div>
          <div>
            <div className="text-sm font-medium">Reddedilmiş</div>
            <div className="text-2xl font-bold">{data.rejected}</div>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>Durum Dağılımı</span>
          <span>Toplam: {total}</span>
        </div>

        <div className="h-4 w-full overflow-hidden rounded-full bg-gray-100">
          {total > 0 && (
            <>
              <div className="h-full bg-gray-300 float-left" style={{ width: `${(data.draft / total) * 100}%` }} />
              <div className="h-full bg-amber-300 float-left" style={{ width: `${(data.review / total) * 100}%` }} />
              <div className="h-full bg-green-300 float-left" style={{ width: `${(data.approved / total) * 100}%` }} />
              <div className="h-full bg-red-300 float-left" style={{ width: `${(data.rejected / total) * 100}%` }} />
              <div className="h-full bg-gray-400 float-left" style={{ width: `${(data.expired / total) * 100}%` }} />
            </>
          )}
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-gray-300" />
            <span>Taslak</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-amber-300" />
            <span>İncelemede</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-green-300" />
            <span>Onaylanmış</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-red-300" />
            <span>Reddedilmiş</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-gray-400" />
            <span>Süresi Dolmuş</span>
          </div>
        </div>
      </div>
    </div>
  )
}
