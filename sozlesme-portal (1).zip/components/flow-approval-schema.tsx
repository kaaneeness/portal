"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { CheckCircle, Clock, AlertCircle, Send } from "lucide-react"
import type { FlowApprover } from "@/types"

interface FlowApprovalSchemaProps {
  approvers: FlowApprover[]
  canManage: boolean
  flowId: string
}

export function FlowApprovalSchema({ approvers, canManage, flowId }: FlowApprovalSchemaProps) {
  const [selectedApprover, setSelectedApprover] = useState<FlowApprover | null>(null)
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false)
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)
  const [isSendDialogOpen, setIsSendDialogOpen] = useState(false)
  const [notes, setNotes] = useState("")
  const { toast } = useToast()

  // Durum badgesi
  const getStatusBadge = (status: FlowApprover["status"]) => {
    switch (status) {
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Onaylandı
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            İncelemede
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            Reddedildi
          </Badge>
        )
      case "not_started":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            Beklemede
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Durum ikonu
  const getStatusIcon = (status: FlowApprover["status"]) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "pending":
        return <Clock className="h-5 w-5 text-amber-500" />
      case "rejected":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "not_started":
        return <Clock className="h-5 w-5 text-gray-400" />
      default:
        return <Clock className="h-5 w-5 text-gray-500" />
    }
  }

  // Tarih formatla
  const formatDate = (date: Date | null) => {
    if (!date) return "-"
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  const handleApprove = () => {
    if (!selectedApprover) return

    // Onay işlemi burada yapılacak
    toast({
      title: "Onaylandı",
      description: `${selectedApprover.name} tarafından onaylandı.`,
    })
    setIsApproveDialogOpen(false)
    setNotes("")
  }

  const handleReject = () => {
    if (!selectedApprover) return

    // Red işlemi burada yapılacak
    toast({
      title: "Reddedildi",
      description: `${selectedApprover.name} tarafından reddedildi.`,
      variant: "destructive",
    })
    setIsRejectDialogOpen(false)
    setNotes("")
  }

  const handleSendToApprover = () => {
    if (!selectedApprover) return

    // Onaya gönderme işlemi burada yapılacak
    toast({
      title: "Onaya Gönderildi",
      description: `${selectedApprover.name} onayına gönderildi.`,
    })
    setIsSendDialogOpen(false)
    setNotes("")
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col space-y-4">
        {approvers.map((approver, index) => (
          <Card key={approver.id} className={approver.status === "pending" ? "border-amber-300" : ""}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon(approver.status)}
                  <div>
                    <h3 className="font-medium">{approver.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {approver.type === "department" ? "Departman" : approver.type === "committee" ? "Komite" : "Kişi"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(approver.status)}

                  {canManage && approver.status === "not_started" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedApprover(approver)
                        setIsSendDialogOpen(true)
                      }}
                    >
                      <Send className="mr-1 h-3 w-3" />
                      Gönder
                    </Button>
                  )}

                  {canManage && approver.status === "pending" && (
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => {
                          setSelectedApprover(approver)
                          setIsApproveDialogOpen(true)
                        }}
                      >
                        Onayla
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                        onClick={() => {
                          setSelectedApprover(approver)
                          setIsRejectDialogOpen(true)
                        }}
                      >
                        Reddet
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {approver.status !== "not_started" && (
                <div className="mt-2 text-sm">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Atanma: {formatDate(approver.assignedAt)}</span>
                    {approver.completedAt && <span>Tamamlanma: {formatDate(approver.completedAt)}</span>}
                  </div>
                  {approver.notes && (
                    <div className="mt-2 rounded-md bg-gray-50 p-2">
                      <p className="text-sm">{approver.notes}</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Onay Diyaloğu */}
      <Dialog open={isApproveDialogOpen} onOpenChange={setIsApproveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Onay</DialogTitle>
            <DialogDescription>{selectedApprover?.name} için onay işlemini tamamlayın.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Textarea placeholder="Notlar (isteğe bağlı)" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApproveDialogOpen(false)}>
              İptal
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={handleApprove}>
              Onayla
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Red Diyaloğu */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reddet</DialogTitle>
            <DialogDescription>{selectedApprover?.name} için red işlemini tamamlayın.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Textarea placeholder="Red gerekçesi" value={notes} onChange={(e) => setNotes(e.target.value)} required />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
              İptal
            </Button>
            <Button variant="destructive" onClick={handleReject} disabled={!notes.trim()}>
              Reddet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Gönderme Diyaloğu */}
      <Dialog open={isSendDialogOpen} onOpenChange={setIsSendDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Onaya Gönder</DialogTitle>
            <DialogDescription>Sözleşmeyi {selectedApprover?.name} onayına göndermek üzeresiniz.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Textarea placeholder="Notlar (isteğe bağlı)" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSendDialogOpen(false)}>
              İptal
            </Button>
            <Button onClick={handleSendToApprover}>
              <Send className="mr-2 h-4 w-4" />
              Gönder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
