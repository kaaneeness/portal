"use client"

import { useState } from "react"
import Link from "next/link"
import type { Contract } from "@/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Clock, Search } from "lucide-react"
import { db } from "@/lib/db"
import { useToast } from "@/components/ui/use-toast"

interface ApprovalListProps {
  contracts: Contract[]
}

export function ApprovalList({ contracts }: ApprovalListProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const { toast } = useToast()

  // Sözleşmeleri filtrele
  const filteredContracts = contracts.filter(
    (contract) =>
      contract.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Departman adını bul
  const getDepartmentName = (id: string) => {
    return db.departments.find((d) => d.id === id)?.name || "Bilinmeyen Departman"
  }

  // Oluşturan kullanıcı adını bul
  const getCreatorName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  const handleApprove = (contractId: string) => {
    // Onay işlemi burada yapılacak
    toast({
      title: "Sözleşme onaylandı",
      description: "Sözleşme başarıyla onaylandı.",
    })
  }

  const handleReject = (contractId: string) => {
    // Red işlemi burada yapılacak
    toast({
      title: "Sözleşme reddedildi",
      description: "Sözleşme reddedildi.",
      variant: "destructive",
    })
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Sözleşme ara..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Başlık</TableHead>
              <TableHead>Departman</TableHead>
              <TableHead>Oluşturan</TableHead>
              <TableHead>Tarih</TableHead>
              <TableHead className="text-right">İşlemler</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredContracts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">
                  Onay bekleyen sözleşme bulunamadı.
                </TableCell>
              </TableRow>
            ) : (
              filteredContracts.map((contract) => (
                <TableRow key={contract.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-amber-500" />
                      <div>
                        <Link href={`/dashboard/contracts/${contract.id}`} className="font-medium hover:underline">
                          {contract.title}
                        </Link>
                        <div className="text-sm text-muted-foreground line-clamp-1">{contract.description}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{getDepartmentName(contract.departmentId)}</TableCell>
                  <TableCell>{getCreatorName(contract.createdBy)}</TableCell>
                  <TableCell>{formatDate(contract.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleApprove(contract.id)}
                      >
                        Onayla
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                        onClick={() => handleReject(contract.id)}
                      >
                        Reddet
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
