"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { db } from "@/lib/db"
import { Loader2, Upload, X, FileText, Plus, Trash } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { tr } from "date-fns/locale"
import { cn } from "@/lib/utils"

export function ManualContractForm() {
  const [title, setTitle] = useState("")
  const [contractNumber, setContractNumber] = useState("")
  const [description, setDescription] = useState("")
  const [departmentId, setDepartmentId] = useState("")
  const [contractType, setContractType] = useState("")
  const [companyName, setCompanyName] = useState("")
  const [companyTaxId, setCompanyTaxId] = useState("")
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState("TRY")
  const [startDate, setStartDate] = useState<Date | undefined>(undefined)
  const [endDate, setEndDate] = useState<Date | undefined>(undefined)
  const [files, setFiles] = useState<File[]>([])
  const [uploadedFiles, setUploadedFiles] = useState<{ name: string; size: number; type: string }[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showAddPartyDialog, setShowAddPartyDialog] = useState(false)
  const [parties, setParties] = useState<{ name: string; role: string; email: string }[]>([])
  const [newPartyName, setNewPartyName] = useState("")
  const [newPartyRole, setNewPartyRole] = useState("")
  const [newPartyEmail, setNewPartyEmail] = useState("")

  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !departmentId || !contractType || !companyName || !startDate) {
      toast({
        title: "Eksik bilgiler",
        description: "Lütfen gerekli alanları doldurun.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Dosya yükleme simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Başarılı mesajı göster
      toast({
        title: "Sözleşme oluşturuldu",
        description: "Sözleşme başarıyla oluşturuldu.",
      })

      // Sözleşmeler sayfasına yönlendir
      router.push("/dashboard/contracts")
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Sözleşme oluşturulurken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files)
      setFiles([...files, ...newFiles])

      // Yüklenen dosyaları simüle et
      const newUploadedFiles = newFiles.map((file) => ({
        name: file.name,
        size: file.size,
        type: file.type,
      }))

      setUploadedFiles([...uploadedFiles, ...newUploadedFiles])
    }
  }

  const removeFile = (index: number) => {
    const newFiles = [...uploadedFiles]
    newFiles.splice(index, 1)
    setUploadedFiles(newFiles)
  }

  const addParty = () => {
    if (newPartyName && newPartyRole) {
      setParties([
        ...parties,
        {
          name: newPartyName,
          role: newPartyRole,
          email: newPartyEmail,
        },
      ])
      setNewPartyName("")
      setNewPartyRole("")
      setNewPartyEmail("")
      setShowAddPartyDialog(false)
    }
  }

  const removeParty = (index: number) => {
    const newParties = [...parties]
    newParties.splice(index, 1)
    setParties(newParties)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " bytes"
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / 1048576).toFixed(1) + " MB"
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Accordion type="single" collapsible defaultValue="temel-bilgiler">
        <AccordionItem value="temel-bilgiler">
          <AccordionTrigger>Temel Bilgiler</AccordionTrigger>
          <AccordionContent>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">
                    Sözleşme Başlığı <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="title"
                    placeholder="Sözleşme başlığını girin"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contractNumber">Sözleşme Numarası</Label>
                  <Input
                    id="contractNumber"
                    placeholder="Sözleşme numarasını girin"
                    value={contractNumber}
                    onChange={(e) => setContractNumber(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contractType">
                    Sözleşme Tipi <span className="text-red-500">*</span>
                  </Label>
                  <Select value={contractType} onValueChange={setContractType} required>
                    <SelectTrigger id="contractType">
                      <SelectValue placeholder="Sözleşme tipi seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="purchase">Satın Alma Sözleşmesi</SelectItem>
                      <SelectItem value="service">Hizmet Sözleşmesi</SelectItem>
                      <SelectItem value="nda">Gizlilik Sözleşmesi</SelectItem>
                      <SelectItem value="partnership">İş Ortaklığı Sözleşmesi</SelectItem>
                      <SelectItem value="employment">İş Sözleşmesi</SelectItem>
                      <SelectItem value="other">Diğer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">
                    Departman <span className="text-red-500">*</span>
                  </Label>
                  <Select value={departmentId} onValueChange={setDepartmentId} required>
                    <SelectTrigger id="department">
                      <SelectValue placeholder="Departman seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {db.departments.map((department) => (
                        <SelectItem key={department.id} value={department.id}>
                          {department.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Açıklama</Label>
                <Textarea
                  id="description"
                  placeholder="Sözleşme hakkında kısa bir açıklama yazın"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="karsi-taraf">
          <AccordionTrigger>Karşı Taraf Bilgileri</AccordionTrigger>
          <AccordionContent>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">
                    Firma/Kişi Adı <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="companyName"
                    placeholder="Firma veya kişi adını girin"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companyTaxId">Vergi/TC Kimlik No</Label>
                  <Input
                    id="companyTaxId"
                    placeholder="Vergi veya TC kimlik numarasını girin"
                    value={companyTaxId}
                    onChange={(e) => setCompanyTaxId(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between mb-2">
                  <Label>İlgili Kişiler</Label>
                  <Dialog open={showAddPartyDialog} onOpenChange={setShowAddPartyDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" type="button">
                        <Plus className="h-4 w-4 mr-1" /> Kişi Ekle
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>İlgili Kişi Ekle</DialogTitle>
                        <DialogDescription>Sözleşmeyle ilgili kişi bilgilerini girin.</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="partyName">Ad Soyad</Label>
                          <Input
                            id="partyName"
                            placeholder="Ad soyad girin"
                            value={newPartyName}
                            onChange={(e) => setNewPartyName(e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="partyRole">Pozisyon/Rol</Label>
                          <Input
                            id="partyRole"
                            placeholder="Pozisyon veya rol girin"
                            value={newPartyRole}
                            onChange={(e) => setNewPartyRole(e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="partyEmail">E-posta</Label>
                          <Input
                            id="partyEmail"
                            type="email"
                            placeholder="E-posta adresi girin"
                            value={newPartyEmail}
                            onChange={(e) => setNewPartyEmail(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowAddPartyDialog(false)}>
                          İptal
                        </Button>
                        <Button type="button" onClick={addParty}>
                          Ekle
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>

                {parties.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Ad Soyad</TableHead>
                        <TableHead>Pozisyon/Rol</TableHead>
                        <TableHead>E-posta</TableHead>
                        <TableHead className="w-[80px]"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {parties.map((party, index) => (
                        <TableRow key={index}>
                          <TableCell>{party.name}</TableCell>
                          <TableCell>{party.role}</TableCell>
                          <TableCell>{party.email}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="icon" type="button" onClick={() => removeParty(index)}>
                              <Trash className="h-4 w-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-4 text-muted-foreground text-sm border rounded-md">
                    Henüz ilgili kişi eklenmedi
                  </div>
                )}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="finansal-bilgiler">
          <AccordionTrigger>Finansal Bilgiler</AccordionTrigger>
          <AccordionContent>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Tutar</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency">Para Birimi</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Para birimi seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TRY">TRY - Türk Lirası</SelectItem>
                      <SelectItem value="USD">USD - Amerikan Doları</SelectItem>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="GBP">GBP - İngiliz Sterlini</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="tarih-bilgileri">
          <AccordionTrigger>Tarih Bilgileri</AccordionTrigger>
          <AccordionContent>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">
                    Başlangıç Tarihi <span className="text-red-500">*</span>
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !startDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {startDate ? format(startDate, "PPP", { locale: tr }) : "Tarih seçin"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate">Bitiş Tarihi</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !endDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {endDate ? format(endDate, "PPP", { locale: tr }) : "Tarih seçin"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        initialFocus
                        disabled={(date) => (startDate ? date < startDate : false)}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="dosyalar">
          <AccordionTrigger>Dosyalar</AccordionTrigger>
          <AccordionContent>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="file">
                  Sözleşme Dosyası <span className="text-red-500">*</span>
                </Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="file"
                    type="file"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                    onChange={handleFileChange}
                    className="hidden"
                    multiple
                  />
                  <div className="grid w-full gap-2">
                    <Label
                      htmlFor="file"
                      className="flex h-32 cursor-pointer flex-col items-center justify-center rounded-md border border-dashed border-gray-300 bg-gray-50 px-3 py-5 text-center transition-colors hover:bg-gray-100"
                    >
                      <Upload className="h-6 w-6 text-muted-foreground" />
                      <div className="mt-2 text-sm text-muted-foreground">
                        Dosyaları sürükleyin veya{" "}
                        <span className="font-medium text-primary">yüklemek için tıklayın</span>
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        PDF, Word, Excel veya görsel dosyaları (maks. 10MB)
                      </div>
                    </Label>
                  </div>
                </div>

                {uploadedFiles.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <Label>Yüklenen Dosyalar</Label>
                    <div className="rounded-md border divide-y">
                      {uploadedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between p-3">
                          <div className="flex items-center space-x-3">
                            <FileText className="h-5 w-5 text-blue-500" />
                            <div>
                              <p className="text-sm font-medium">{file.name}</p>
                              <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                            </div>
                          </div>
                          <Button variant="ghost" size="icon" type="button" onClick={() => removeFile(index)}>
                            <X className="h-4 w-4 text-muted-foreground" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <div className="flex justify-end space-x-2 pt-4">
        <Button variant="outline" type="button" onClick={() => router.push("/dashboard/contracts")}>
          İptal
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Oluşturuluyor...
            </>
          ) : (
            "Sözleşme Oluştur"
          )}
        </Button>
      </div>
    </form>
  )
}
