import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { db } from "@/lib/db"

interface FlowParticipantsProps {
  assignedUsers: string[]
}

export function FlowParticipants({ assignedUsers }: FlowParticipantsProps) {
  // Kullanıcı bilgilerini bul
  const users = assignedUsers
    .map((id) => {
      const user = db.users.find((u) => u.id === id)
      if (!user) return null

      const department = db.departments.find((d) => d.id === user.departmentId)

      return {
        ...user,
        departmentName: department?.name || "Bilinmeyen Departman",
      }
    })
    .filter(Boolean)

  // Kullanıcı baş harflerini al
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  if (users.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">Bu akış için henüz katılımcı atanmamış.</div>
  }

  return (
    <div className="space-y-4">
      {users.map((user) => (
        <div key={user!.id} className="flex items-center gap-4 p-3 rounded-md border">
          <Avatar className="h-10 w-10">
            <AvatarFallback>{getInitials(user!.name)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <p className="font-medium">{user!.name}</p>
            <p className="text-sm text-muted-foreground">{user!.departmentName}</p>
          </div>
          <div className="text-sm text-muted-foreground">
            {user!.role === "admin" ? "Yönetici" : user!.role === "manager" ? "Müdür" : "Kullanıcı"}
          </div>
        </div>
      ))}
    </div>
  )
}
