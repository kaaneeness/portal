"use client"

import { useState } from "react"
import Link from "next/link"
import type { ContractFlow } from "@/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { GitPullRequest, MoreHorizontal, Search, Clock, CheckCircle, AlertCircle, FileText } from "lucide-react"
import { db } from "@/lib/db"

interface FlowListProps {
  flows: ContractFlow[]
}

export function FlowList({ flows }: FlowListProps) {
  const [searchTerm, setSearchTerm] = useState("")

  // Akışları filtrele
  const filteredFlows = flows.filter(
    (flow) =>
      flow.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      flow.counterpartyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (flow.poNumber && flow.poNumber.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  // Departman adını bul
  const getDepartmentName = (id: string) => {
    return db.departments.find((d) => d.id === id)?.name || "Bilinmeyen Departman"
  }

  // Oluşturan kullanıcı adını bul
  const getCreatorName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Durum badgesi
  const getStatusBadge = (status: ContractFlow["status"]) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Aktif
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            Beklemede
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Tamamlandı
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            İptal Edildi
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Aşama badgesi
  const getStageBadge = (stage: ContractFlow["stage"]) => {
    switch (stage) {
      case "draft_upload":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            Taslak Yükleme
          </Badge>
        )
      case "legal_review":
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800 hover:bg-purple-100">
            Hukuk İncelemesi
          </Badge>
        )
      case "department_review":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Departman İncelemesi
          </Badge>
        )
      case "negotiation":
        return (
          <Badge variant="outline" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            Müzakere
          </Badge>
        )
      case "final_approval":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Final Onayı
          </Badge>
        )
      case "signature":
        return (
          <Badge variant="outline" className="bg-indigo-100 text-indigo-800 hover:bg-indigo-100">
            İmza
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Tamamlandı
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Durum ikonu
  const getStatusIcon = (status: ContractFlow["status"]) => {
    switch (status) {
      case "active":
        return <GitPullRequest className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-amber-500" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-blue-500" />
      case "cancelled":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <GitPullRequest className="h-4 w-4 text-gray-500" />
    }
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Akış ara (başlık, firma, PO no)..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Durum</TableHead>
              <TableHead>Başlık</TableHead>
              <TableHead>Karşı Taraf</TableHead>
              <TableHead>Departman</TableHead>
              <TableHead>Aşama</TableHead>
              <TableHead>Tarih</TableHead>
              <TableHead className="text-right">İşlemler</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredFlows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  Akış bulunamadı.
                </TableCell>
              </TableRow>
            ) : (
              filteredFlows.map((flow) => (
                <TableRow key={flow.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(flow.status)}
                      {getStatusBadge(flow.status)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Link href={`/dashboard/flows/${flow.id}`} className="font-medium hover:underline">
                      {flow.title}
                    </Link>
                    {flow.poNumber && <div className="text-sm text-muted-foreground">PO: {flow.poNumber}</div>}
                  </TableCell>
                  <TableCell>{flow.counterpartyName}</TableCell>
                  <TableCell>{getDepartmentName(flow.departmentId)}</TableCell>
                  <TableCell>{getStageBadge(flow.stage)}</TableCell>
                  <TableCell>{formatDate(flow.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Menüyü aç</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>İşlemler</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Link href={`/dashboard/flows/${flow.id}`} className="flex w-full">
                            Görüntüle
                          </Link>
                        </DropdownMenuItem>
                        {flow.documents.length > 0 && (
                          <DropdownMenuItem>
                            <Link
                              href={flow.documents[flow.documents.length - 1].url}
                              target="_blank"
                              className="flex w-full"
                            >
                              <FileText className="mr-2 h-4 w-4" />
                              Son Dosyayı İndir
                            </Link>
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
