"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { ManualFlowForm } from "@/components/manual-flow-form"
import { SapFlowForm } from "@/components/sap-flow-form"

export function NewFlowForm() {
  const [activeTab, setActiveTab] = useState<"manual" | "sap">("manual")
  const router = useRouter()
  const { toast } = useToast()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sözleşme Akışı Bilgileri</CardTitle>
        <CardDescription>
          Yeni sözleşme akışı için bilgileri SAP'den getirebilir veya manuel olarak girebilirsiniz
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="manual" onValueChange={(value) => setActiveTab(value as "manual" | "sap")}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="manual">Manuel Oluştur</TabsTrigger>
            <TabsTrigger value="sap">SAP'den Getir</TabsTrigger>
          </TabsList>
          <TabsContent value="manual">
            <ManualFlowForm />
          </TabsContent>
          <TabsContent value="sap">
            <SapFlowForm />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
