"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Upload, Loader2 } from "lucide-react"
import type { DocumentType } from "@/types"

interface FlowDocumentUploadProps {
  flowId: string
  onSuccess?: () => void
}

export function FlowDocumentUpload({ flowId, onSuccess }: FlowDocumentUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [documentType, setDocumentType] = useState<DocumentType | "">("")
  const [isUploading, setIsUploading] = useState(false)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0])
    }
  }

  const handleUpload = async () => {
    if (!file || !documentType) {
      toast({
        title: "Eksik bilgiler",
        description: "Lütfen bir dosya seçin ve belge türünü belirtin.",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    try {
      // Dosya yükleme simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Belge yüklendi",
        description: "Belge başarıyla yüklendi.",
      })

      // Formu temizle
      setFile(null)
      setDocumentType("")

      // Başarı callback'i
      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      toast({
        title: "Yükleme başarısız",
        description: "Belge yüklenirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Belge Yükle</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="document-type">Belge Türü</Label>
          <Select value={documentType} onValueChange={(value) => setDocumentType(value as DocumentType)}>
            <SelectTrigger id="document-type">
              <SelectValue placeholder="Belge türü seçin" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="contract_draft">Sözleşme Taslağı</SelectItem>
              <SelectItem value="activity_certificate">Faaliyet Belgesi</SelectItem>
              <SelectItem value="tax_certificate">Vergi Levhası</SelectItem>
              <SelectItem value="signature_circular">İmza Sirküleri</SelectItem>
              <SelectItem value="contract_control_form">Sözleşme Kontrol Formu</SelectItem>
              <SelectItem value="support_services_form">Destek Hizmetleri Sağlayıcısı Kontrol Formu</SelectItem>
              <SelectItem value="other">Diğer</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="file">Dosya</Label>
          <div className="flex items-center gap-4">
            <input
              id="file"
              type="file"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="grid w-full gap-2">
              <Label
                htmlFor="file"
                className="flex h-24 cursor-pointer flex-col items-center justify-center rounded-md border border-dashed border-gray-300 bg-gray-50 px-3 py-5 text-center transition-colors hover:bg-gray-100"
              >
                <Upload className="h-6 w-6 text-muted-foreground" />
                <div className="mt-2 text-sm text-muted-foreground">
                  {file ? file.name : "Dosyayı sürükleyin veya yüklemek için tıklayın"}
                </div>
              </Label>
            </div>
          </div>
        </div>

        <Button className="w-full" onClick={handleUpload} disabled={isUploading || !file || !documentType}>
          {isUploading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Yükleniyor...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Belgeyi Yükle
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
