"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { ApprovalStep } from "@/types"
import { db } from "@/lib/db"
import { CheckCircle, Clock, XCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

interface ApprovalFlowProps {
  steps: ApprovalStep[]
  contractId: string
  canApprove: boolean
}

export function ApprovalFlow({ steps, contractId, canApprove }: ApprovalFlowProps) {
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false)
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)
  const [comment, setComment] = useState("")
  const { toast } = useToast()

  // Kullanıcı adını bul
  const getUserName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Departman adını bul
  const getDepartmentName = (id: string) => {
    return db.departments.find((d) => d.id === id)?.name || "Bilinmeyen Departman"
  }

  // Durum badgesi
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline">Bekliyor</Badge>
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Onaylandı
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            Reddedildi
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Durum ikonu
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4 text-gray-500" />
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  // Tarih formatla
  const formatDate = (date: Date | null) => {
    if (!date) return "-"
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  const handleApprove = () => {
    // Onay işlemi burada yapılacak
    toast({
      title: "Sözleşme onaylandı",
      description: "Sözleşme başarıyla onaylandı.",
    })
    setIsApproveDialogOpen(false)
    setComment("")
  }

  const handleReject = () => {
    // Red işlemi burada yapılacak
    toast({
      title: "Sözleşme reddedildi",
      description: "Sözleşme reddedildi.",
      variant: "destructive",
    })
    setIsRejectDialogOpen(false)
    setComment("")
  }

  if (steps.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground">Bu sözleşme için henüz onay akışı tanımlanmamış.</div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="space-y-4">
        {steps.map((step, index) => (
          <div key={step.id} className="flex items-start gap-4 p-4 rounded-lg border">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-100">{index + 1}</div>

            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{getUserName(step.userId)}</p>
                  <p className="text-sm text-muted-foreground">{getDepartmentName(step.departmentId)}</p>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(step.status)}
                  {getStatusBadge(step.status)}
                </div>
              </div>

              {step.status !== "pending" && (
                <div className="text-sm">
                  <span className="text-muted-foreground">İşlem Tarihi:</span> {formatDate(step.date)}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {canApprove && (
        <div className="flex space-x-2 mt-4">
          <Dialog open={isApproveDialogOpen} onOpenChange={setIsApproveDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full bg-green-600 hover:bg-green-700">Onayla</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Sözleşmeyi Onayla</DialogTitle>
                <DialogDescription>
                  Bu sözleşmeyi onaylamak üzeresiniz. İsterseniz bir yorum ekleyebilirsiniz.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <Textarea
                  placeholder="Yorum ekleyin (isteğe bağlı)"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsApproveDialogOpen(false)}>
                  İptal
                </Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={handleApprove}>
                  Onayla
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="w-full border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
              >
                Reddet
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Sözleşmeyi Reddet</DialogTitle>
                <DialogDescription>
                  Bu sözleşmeyi reddetmek üzeresiniz. Lütfen red gerekçenizi belirtin.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <Textarea
                  placeholder="Red gerekçesi"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  required
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
                  İptal
                </Button>
                <Button variant="destructive" onClick={handleReject} disabled={!comment.trim()}>
                  Reddet
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      )}
    </div>
  )
}
