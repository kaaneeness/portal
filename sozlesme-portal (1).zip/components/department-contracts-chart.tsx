"use client"

interface DepartmentContractsChartProps {
  data: {
    name: string
    count: number
  }[]
}

export function DepartmentContractsChart({ data }: DepartmentContractsChartProps) {
  // Bu bileşen gerçek bir grafik kütüphanesi kullanılarak geliştirilebilir
  // Örneğin: Chart.js, Recharts, veya D3.js

  const maxCount = Math.max(...data.map((item) => item.count))

  return (
    <div className="space-y-4">
      {data.map((item, index) => (
        <div key={index} className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>{item.name}</span>
            <span>{item.count}</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-gray-100">
            <div className="h-full bg-blue-500" style={{ width: `${(item.count / maxCount) * 100}%` }} />
          </div>
        </div>
      ))}
    </div>
  )
}
