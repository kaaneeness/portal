"use client"

import { useState } from "react"
import Link from "next/link"
import type { Contract } from "@/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, File, MoreHorizontal, Search, XCircle } from "lucide-react"
import { db } from "@/lib/db"

interface ContractListProps {
  contracts: Contract[]
}

export function ContractList({ contracts }: ContractListProps) {
  const [searchTerm, setSearchTerm] = useState("")

  // Sözleşmeleri filtrele
  const filteredContracts = contracts.filter(
    (contract) =>
      contract.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Departman adını bul
  const getDepartmentName = (id: string) => {
    return db.departments.find((d) => d.id === id)?.name || "Bilinmeyen Departman"
  }

  // Oluşturan kullanıcı adını bul
  const getCreatorName = (id: string) => {
    return db.users.find((u) => u.id === id)?.name || "Bilinmeyen Kullanıcı"
  }

  // Durum badgesi
  const getStatusBadge = (status: Contract["status"]) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Taslak</Badge>
      case "review":
        return (
          <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            İncelemede
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Onaylandı
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            Reddedildi
          </Badge>
        )
      case "expired":
        return (
          <Badge variant="secondary" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            Süresi Doldu
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Durum ikonu
  const getStatusIcon = (status: Contract["status"]) => {
    switch (status) {
      case "draft":
        return <File className="h-4 w-4 text-gray-500" />
      case "review":
        return <Clock className="h-4 w-4 text-amber-500" />
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <File className="h-4 w-4 text-gray-500" />
    }
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Sözleşme ara..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Durum</TableHead>
              <TableHead>Başlık</TableHead>
              <TableHead>Departman</TableHead>
              <TableHead>Oluşturan</TableHead>
              <TableHead>Tarih</TableHead>
              <TableHead className="text-right">İşlemler</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredContracts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  Sözleşme bulunamadı.
                </TableCell>
              </TableRow>
            ) : (
              filteredContracts.map((contract) => (
                <TableRow key={contract.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(contract.status)}
                      {getStatusBadge(contract.status)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Link href={`/dashboard/contracts/${contract.id}`} className="font-medium hover:underline">
                      {contract.title}
                    </Link>
                    <div className="text-sm text-muted-foreground line-clamp-1">{contract.description}</div>
                  </TableCell>
                  <TableCell>{getDepartmentName(contract.departmentId)}</TableCell>
                  <TableCell>{getCreatorName(contract.createdBy)}</TableCell>
                  <TableCell>{formatDate(contract.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Menüyü aç</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>İşlemler</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Link href={`/dashboard/contracts/${contract.id}`} className="flex w-full">
                            Görüntüle
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Link href={`/dashboard/contracts/${contract.id}/edit`} className="flex w-full">
                            Düzenle
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Link href={contract.documentUrl} target="_blank" className="flex w-full">
                            Dosyayı İndir
                          </Link>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
