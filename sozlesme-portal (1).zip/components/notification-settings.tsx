"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

export function NotificationSettings() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  // Bildirim ayarları
  const [notifications, setNotifications] = useState({
    newContract: true,
    contractUpdated: true,
    approvalRequired: true,
    contractApproved: true,
    contractRejected: true,
    commentAdded: false,
    userMention: true,
    systemUpdates: false,
  })

  const handleCheckboxChange = (key: keyof typeof notifications) => {
    setNotifications((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Bildirim ayarları güncelleme simülasyonu
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Bildirim ayarları güncellendi",
        description: "Bildirim tercihleriniz başarıyla kaydedildi.",
      })
    } catch (error) {
      toast({
        title: "Bir hata oluştu",
        description: "Bildirim ayarları güncellenirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Sözleşme Bildirimleri</h3>

        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="newContract"
              checked={notifications.newContract}
              onCheckedChange={() => handleCheckboxChange("newContract")}
            />
            <Label htmlFor="newContract">Yeni sözleşme oluşturulduğunda</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="contractUpdated"
              checked={notifications.contractUpdated}
              onCheckedChange={() => handleCheckboxChange("contractUpdated")}
            />
            <Label htmlFor="contractUpdated">Sözleşme güncellendiğinde</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="approvalRequired"
              checked={notifications.approvalRequired}
              onCheckedChange={() => handleCheckboxChange("approvalRequired")}
            />
            <Label htmlFor="approvalRequired">Onayınız gerektiğinde</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="contractApproved"
              checked={notifications.contractApproved}
              onCheckedChange={() => handleCheckboxChange("contractApproved")}
            />
            <Label htmlFor="contractApproved">Sözleşme onaylandığında</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="contractRejected"
              checked={notifications.contractRejected}
              onCheckedChange={() => handleCheckboxChange("contractRejected")}
            />
            <Label htmlFor="contractRejected">Sözleşme reddedildiğinde</Label>
          </div>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <h3 className="text-lg font-medium">Diğer Bildirimler</h3>

        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="commentAdded"
              checked={notifications.commentAdded}
              onCheckedChange={() => handleCheckboxChange("commentAdded")}
            />
            <Label htmlFor="commentAdded">Yorum eklendiğinde</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="userMention"
              checked={notifications.userMention}
              onCheckedChange={() => handleCheckboxChange("userMention")}
            />
            <Label htmlFor="userMention">Biri sizi etiketlediğinde</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="systemUpdates"
              checked={notifications.systemUpdates}
              onCheckedChange={() => handleCheckboxChange("systemUpdates")}
            />
            <Label htmlFor="systemUpdates">Sistem güncellemeleri ve duyurular</Label>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Kaydediliyor...
            </>
          ) : (
            "Değişiklikleri Kaydet"
          )}
        </Button>
      </div>
    </form>
  )
}
