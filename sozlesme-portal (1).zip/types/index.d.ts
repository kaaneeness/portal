import type { DefaultSession } from "next-auth"

declare module "next-auth" {
  interface User {
    id: string
    role: string
    departmentId: string
  }

  interface Session {
    user: {
      id: string
      role: string
      departmentId: string
    } & DefaultSession["user"]
  }
}

export type Department = {
  id: string
  name: string
}

export type User = {
  id: string
  name: string
  email: string
  role: string
  departmentId: string
}

export type ApprovalStep = {
  id: string
  userId: string
  departmentId: string
  status: "pending" | "approved" | "rejected"
  date: Date | null
}

export type Contract = {
  id: string
  title: string
  description: string
  status: "draft" | "review" | "approved" | "rejected" | "expired"
  createdBy: string
  createdAt: Date
  departmentId: string
  documentUrl: string
  approvalFlow: ApprovalStep[]
}

export type FlowStage =
  | "draft_upload"
  | "legal_review"
  | "department_review"
  | "negotiation"
  | "final_approval"
  | "signature"
  | "completed"

export type FlowStatus = "active" | "pending" | "completed" | "cancelled"

export type FlowApprover = {
  id: string
  type: "department" | "committee" | "individual"
  name: string
  status: "pending" | "approved" | "rejected" | "not_started"
  assignedAt: Date | null
  completedAt: Date | null
  notes?: string
}

export type DocumentType =
  | "contract_draft"
  | "activity_certificate"
  | "tax_certificate"
  | "signature_circular"
  | "contract_control_form"
  | "support_services_form"
  | "other"

export type ContractFlow = {
  id: string
  title: string
  poNumber?: string
  counterpartyName: string
  counterpartyTaxId?: string
  description?: string
  status: FlowStatus
  stage: FlowStage
  createdBy: string
  createdAt: Date
  departmentId: string
  responsibleUserId: string // Sözleşme sorumlusu
  assignedTo: string[]
  approvers: FlowApprover[] // Onaylayıcılar (departmanlar, komiteler)
  documents: FlowDocument[]
  comments: FlowComment[]
  history: FlowHistory[]
}

export type FlowDocument = {
  id: string
  name: string
  url: string
  type: DocumentType
  version: number
  uploadedBy: string
  uploadedAt: Date
  status: "draft" | "reviewed" | "approved" | "rejected" | "final"
}

export type FlowComment = {
  id: string
  text: string
  userId: string
  createdAt: Date
  documentId?: string
}

export type FlowHistory = {
  id: string
  action: string
  userId: string
  timestamp: Date
  details?: string
}
