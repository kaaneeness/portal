import { db } from "@/lib/db"
import { DashboardStats } from "@/components/dashboard-stats"
import { ContractList } from "@/components/contract-list"
import type { Contract } from "@/types"

export default function DashboardPage() {
  // Varsayılan olarak admin kullanıcısını kullan
  const user = {
    id: "1",
    name: "Admin Kullanıcı",
    email: "admin@sirket.com",
    role: "admin",
    departmentId: "1",
  }

  // Admin kullanıcısı tüm sözleşmeleri görebilir
  const contracts: Contract[] = db.contracts

  // İstatistikler için veri hazırla
  const stats = {
    total: contracts.length,
    draft: contracts.filter((c) => c.status === "draft").length,
    review: contracts.filter((c) => c.status === "review").length,
    approved: contracts.filter((c) => c.status === "approved").length,
    rejected: contracts.filter((c) => c.status === "rejected").length,
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Hoş Geldiniz, {user.name}</h1>

      <DashboardStats stats={stats} />

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Sözleşmelerim</h2>
        <ContractList contracts={contracts} />
      </div>
    </div>
  )
}
