import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { NewContractForm } from "@/components/new-contract-form"

export default function NewContractPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Button variant="outline" size="icon" asChild>
          <Link href="/dashboard/contracts">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Geri</span>
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Yeni Sözleşme Oluştur</h1>
      </div>

      <NewContractForm />
    </div>
  )
}
