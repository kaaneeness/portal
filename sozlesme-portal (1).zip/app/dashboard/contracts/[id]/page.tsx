"use client"

import { notFound } from "next/navigation"
import Link from "next/link"
import { db } from "@/lib/db"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ApprovalFlow } from "@/components/approval-flow"
import { ArrowLeft, Download, Edit, Eye } from "lucide-react"

interface ContractDetailPageProps {
  params: {
    id: string
  }
}

export default function ContractDetailPage({ params }: ContractDetailPageProps) {
  // Varsayılan olarak admin kullanıcısını kullan
  const user = {
    id: "1",
    name: "Admin Kullanıcı",
    email: "admin@sirket.com",
    role: "admin",
    departmentId: "1",
  }

  // Sözleşmeyi bul
  const contract = db.contracts.find((c) => c.id === params.id)

  if (!contract) {
    notFound()
  }

  // Departman adını bul
  const department = db.departments.find((d) => d.id === contract.departmentId)

  // Oluşturan kullanıcı adını bul
  const creator = db.users.find((u) => u.id === contract.createdBy)

  // Durum badgesi
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Taslak</Badge>
      case "review":
        return (
          <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            İncelemede
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Onaylandı
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            Reddedildi
          </Badge>
        )
      case "expired":
        return (
          <Badge variant="secondary" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            Süresi Doldu
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  // Kullanıcının bu sözleşmeyi düzenleme yetkisi var mı?
  const canEdit = user.role === "admin" || (user.id === contract.createdBy && contract.status === "draft")

  // Kullanıcının bu sözleşmeyi onaylama yetkisi var mı?
  const pendingApproval = contract.approvalFlow.find(
    (step) => step.departmentId === user.departmentId && step.status === "pending",
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="/dashboard/contracts">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Geri</span>
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{contract.title}</h1>
          {getStatusBadge(contract.status)}
        </div>

        <div className="flex space-x-2">
          <Button variant="outline" size="sm" asChild>
            <Link href={contract.documentUrl} target="_blank">
              <Download className="mr-2 h-4 w-4" />
              Dosyayı İndir
            </Link>
          </Button>

          <Button variant="outline" size="sm" asChild>
            <Link href={`/dashboard/contracts/${contract.id}/preview`}>
              <Eye className="mr-2 h-4 w-4" />
              Önizle
            </Link>
          </Button>

          {canEdit && (
            <Button size="sm" asChild>
              <Link href={`/dashboard/contracts/${contract.id}/edit`}>
                <Edit className="mr-2 h-4 w-4" />
                Düzenle
              </Link>
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="space-y-6 md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Sözleşme Detayları</CardTitle>
              <CardDescription>Sözleşme bilgileri ve açıklaması</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Açıklama</h3>
                <p className="mt-1">{contract.description}</p>
              </div>

              <Separator />

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Departman</h3>
                  <p className="mt-1">{department?.name}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Oluşturan</h3>
                  <p className="mt-1">{creator?.name}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Oluşturma Tarihi</h3>
                  <p className="mt-1">{formatDate(contract.createdAt)}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Durum</h3>
                  <p className="mt-1 flex items-center">{getStatusBadge(contract.status)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Onay Akışı</CardTitle>
              <CardDescription>Sözleşme onay süreci ve durumu</CardDescription>
            </CardHeader>
            <CardContent>
              <ApprovalFlow steps={contract.approvalFlow} contractId={contract.id} canApprove={!!pendingApproval} />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sözleşme Bilgileri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Sözleşme ID</h3>
                <p className="mt-1 font-mono text-sm">{contract.id}</p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Dosya</h3>
                <p className="mt-1 truncate">
                  <Link href={contract.documentUrl} target="_blank" className="text-sm text-blue-600 hover:underline">
                    Sözleşme Dosyası
                  </Link>
                </p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Onay Adımları</h3>
                <p className="mt-1">{contract.approvalFlow.length} adım</p>
              </div>
            </CardContent>
          </Card>

          {pendingApproval && (
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <CardTitle className="text-amber-800">Onay Bekliyor</CardTitle>
                <CardDescription className="text-amber-700">Bu sözleşme sizin onayınızı bekliyor</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-2">
                  <Button
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => {
                      // Onay işlemi burada yapılacak
                      alert("Sözleşme onaylandı")
                    }}
                  >
                    Onayla
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                    onClick={() => {
                      // Red işlemi burada yapılacak
                      alert("Sözleşme reddedildi")
                    }}
                  >
                    Reddet
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
