import { db } from "@/lib/db"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ContractStatusChart } from "@/components/contract-status-chart"
import { DepartmentContractsChart } from "@/components/department-contracts-chart"
import { RecentActivityList } from "@/components/recent-activity-list"

export default function ReportsPage() {
  // Sözleşme durumlarına göre sayıları hesapla
  const statusCounts = {
    draft: db.contracts.filter((c) => c.status === "draft").length,
    review: db.contracts.filter((c) => c.status === "review").length,
    approved: db.contracts.filter((c) => c.status === "approved").length,
    rejected: db.contracts.filter((c) => c.status === "rejected").length,
    expired: db.contracts.filter((c) => c.status === "expired").length,
  }

  // Departmanlara göre sözleşme sayılarını hesapla
  const departmentCounts = db.departments.map((department) => ({
    name: department.name,
    count: db.contracts.filter((c) => c.departmentId === department.id).length,
  }))

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Raporlar ve İstatistikler</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Sözleşme Durumları</CardTitle>
            <CardDescription>Sözleşmelerin durumlarına göre dağılımı</CardDescription>
          </CardHeader>
          <CardContent>
            <ContractStatusChart data={statusCounts} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Departman Bazlı Sözleşmeler</CardTitle>
            <CardDescription>Departmanlara göre sözleşme sayıları</CardDescription>
          </CardHeader>
          <CardContent>
            <DepartmentContractsChart data={departmentCounts} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Son Aktiviteler</CardTitle>
          <CardDescription>Sistemdeki son işlemler ve değişiklikler</CardDescription>
        </CardHeader>
        <CardContent>
          <RecentActivityList />
        </CardContent>
      </Card>
    </div>
  )
}
