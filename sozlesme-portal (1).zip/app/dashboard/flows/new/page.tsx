import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { NewFlowForm } from "@/components/new-flow-form"

export default function NewFlowPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Button variant="outline" size="icon" asChild>
          <Link href="/dashboard/flows">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Geri</span>
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Yeni Sözleşme Akışı Başlat</h1>
      </div>

      <NewFlowForm />
    </div>
  )
}
