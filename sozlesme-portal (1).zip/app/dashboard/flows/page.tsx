import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { db } from "@/lib/db"
import { FlowList } from "@/components/flow-list"
import type { ContractFlow } from "@/types"

export default function FlowsPage() {
  // Varsayılan olarak admin kullanıcısını kullan
  const user = {
    id: "1",
    name: "Admin Kullanıcı",
    email: "admin@sirket.com",
    role: "admin",
    departmentId: "1",
  }

  // Admin kullanıcısı tüm akışları görebilir
  // Gerçek uygulamada kullanıcının departmanına göre filtreleme yapılabilir
  const flows: ContractFlow[] = db.flows

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Sözleşme Akışları</h1>
        <Button asChild>
          <Link href="/dashboard/flows/new">
            <Plus className="mr-2 h-4 w-4" />
            Yeni Akış Başlat
          </Link>
        </Button>
      </div>

      <FlowList flows={flows} />
    </div>
  )
}
