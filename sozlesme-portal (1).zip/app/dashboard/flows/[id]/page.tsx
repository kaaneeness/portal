"use client"

import { notFound } from "next/navigation"
import Link from "next/link"
import { db } from "@/lib/db"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft } from "lucide-react"
import { FlowManagement } from "@/components/flow-management"
import type { ContractFlow } from "@/types"

interface FlowDetailPageProps {
  params: {
    id: string
  }
}

export default function FlowDetailPage({ params }: FlowDetailPageProps) {
  // Varsayılan olarak admin kullanıcısını kullan
  const user = {
    id: "1",
    name: "Admin Kullanıcı",
    email: "admin@sirket.com",
    role: "admin",
    departmentId: "1",
  }

  // Akışı bul
  const flow = db.flows.find((f) => f.id === params.id)

  if (!flow) {
    notFound()
  }

  // Departman adını bul
  const department = db.departments.find((d) => d.id === flow.departmentId)

  // Oluşturan kullanıcı adını bul
  const creator = db.users.find((u) => u.id === flow.createdBy)

  // Sorumlu kullanıcı adını bul
  const responsible = db.users.find((u) => u.id === flow.responsibleUserId)

  // Kullanıcı bu akışın sorumlusu mu?
  const isResponsible = user.id === flow.responsibleUserId || user.role === "admin"

  // Durum badgesi
  const getStatusBadge = (status: ContractFlow["status"]) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
            Aktif
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            Beklemede
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Tamamlandı
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">
            İptal Edildi
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Aşama badgesi
  const getStageBadge = (stage: ContractFlow["stage"]) => {
    switch (stage) {
      case "draft_upload":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            Taslak Yükleme
          </Badge>
        )
      case "legal_review":
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800 hover:bg-purple-100">
            Hukuk İncelemesi
          </Badge>
        )
      case "department_review":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Departman İncelemesi
          </Badge>
        )
      case "negotiation":
        return (
          <Badge variant="outline" className="bg-amber-100 text-amber-800 hover:bg-amber-100">
            Müzakere
          </Badge>
        )
      case "final_approval":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Final Onayı
          </Badge>
        )
      case "signature":
        return (
          <Badge variant="outline" className="bg-indigo-100 text-indigo-800 hover:bg-indigo-100">
            İmza
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Tamamlandı
          </Badge>
        )
      default:
        return <Badge variant="outline">Bilinmeyen</Badge>
    }
  }

  // Tarih formatla
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="/dashboard/flows">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Geri</span>
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{flow.title}</h1>
          {getStatusBadge(flow.status)}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="space-y-6 md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Akış Detayları</CardTitle>
              <CardDescription>Sözleşme akışı bilgileri ve açıklaması</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {flow.description && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Açıklama</h3>
                  <p className="mt-1">{flow.description}</p>
                </div>
              )}

              <Separator />

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Karşı Taraf</h3>
                  <p className="mt-1">{flow.counterpartyName}</p>
                  {flow.counterpartyTaxId && (
                    <p className="text-sm text-muted-foreground">Vergi No: {flow.counterpartyTaxId}</p>
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Departman</h3>
                  <p className="mt-1">{department?.name}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Oluşturan</h3>
                  <p className="mt-1">{creator?.name}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Sorumlu</h3>
                  <p className="mt-1">{responsible?.name}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Oluşturma Tarihi</h3>
                  <p className="mt-1">{formatDate(flow.createdAt)}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Durum</h3>
                  <p className="mt-1 flex items-center">{getStatusBadge(flow.status)}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Aşama</h3>
                  <p className="mt-1 flex items-center">{getStageBadge(flow.stage)}</p>
                </div>

                {flow.poNumber && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">PO Numarası</h3>
                    <p className="mt-1">{flow.poNumber}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <FlowManagement flow={flow} isResponsible={isResponsible} />
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Akış Bilgileri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Akış ID</h3>
                <p className="mt-1 font-mono text-sm">{flow.id}</p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Doküman Sayısı</h3>
                <p className="mt-1">{flow.documents.length}</p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Yorum Sayısı</h3>
                <p className="mt-1">{flow.comments.length}</p>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Onaylayıcı Sayısı</h3>
                <p className="mt-1">{flow.approvers.length}</p>
              </div>
            </CardContent>
          </Card>

          {isResponsible && flow.stage === "draft_upload" && (
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <CardTitle className="text-amber-800">Taslak Yükleme Aşaması</CardTitle>
                <CardDescription className="text-amber-700">
                  Bu akış için taslak sözleşme yüklenmesi gerekiyor
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" onClick={() => document.getElementById("file")?.click()}>
                  Taslak Sözleşme Yükle
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
