import { db } from "@/lib/db"
import { ApprovalList } from "@/components/approval-list"
import type { Contract } from "@/types"

export default function ApprovalsPage() {
  // Varsayılan olarak admin kullanıcısını kullan
  const user = {
    id: "1",
    name: "Admin Kullanıcı",
    email: "admin@sirket.com",
    role: "admin",
    departmentId: "1",
  }

  // Kullanıcının onay bekleyen sözleşmelerini filtrele
  const pendingContracts: Contract[] = db.contracts.filter((contract) =>
    contract.approvalFlow.some((step) => step.departmentId === user.departmentId && step.status === "pending"),
  )

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Onay Bekleyen Sözleşmeler</h1>

      <ApprovalList contracts={pendingContracts} />
    </div>
  )
}
