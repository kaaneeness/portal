import { redirect } from "next/navigation"

export default function Home() {
  // Doğrudan dashboard'a yönlendir
  redirect("/dashboard")
}
